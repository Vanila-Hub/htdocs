<?php
namespace Dwes\ProyectoVideoclub\app;

    interface Resumible {
        public function muestraResumen();
    }
?>